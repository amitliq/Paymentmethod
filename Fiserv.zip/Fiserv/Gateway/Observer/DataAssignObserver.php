<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Fiserv\Gateway\Observer;

 use Magento\Framework\DataObject;
    use Magento\Framework\Encryption\EncryptorInterface;
    use Magento\Framework\Event\Observer;
    use Magento\Framework\Exception\LocalizedException;
    use Magento\Payment\Observer\AbstractDataAssignObserver;
    use Magento\Quote\Api\Data\PaymentInterface;
    use Magento\Payment\Model\InfoInterface;

    class DataAssignObserver extends AbstractDataAssignObserver
    {
        /**
         * @param Observer $observer
         * @throws LocalizedException
         */
        public function execute(Observer $observer)
        {
            $data = $this->readDataArgument($observer);

            $additionalData = $data->getData(PaymentInterface::KEY_ADDITIONAL_DATA);
		
		if (!is_array($additionalData)) {
                return;
            }

            $paymentModel = $this->readPaymentModelArgument($observer);

            $paymentModel->setAdditionalInformation(
                $additionalData
            );
			

        }
    }
