<?php

namespace Fiserv\Gateway\Logger;

class Logger extends \Monolog\Logger {
    
}